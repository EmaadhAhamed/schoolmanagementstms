﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace SchoolTimeTable
{
    public partial class FrmTD : Form
    {
        public FrmTD()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;Initial Catalog=schooltimetable;User ID=root;Password=123";
            string Query = "INSERT INTO teacher (staffcode, nicno, surname, initials, namebyinitials, dob, gender, address1, address2, address3, address4, contactno)" +
                                 "VALUES('" + this.staffcodetxt.Text + "','" + this.nicnotxt.Text + "','" + this.surnametxt.Text + "','" + this.initialstxt.Text + "','" + this.namesbyinitials.Text + "','" + this.dob.Value.ToString("yyyy-MM-dd") + "','" + this.gendertxt.Text + "','" + this.address1txt.Text + "','" + this.address2txt.Text + "','" + this.address3txt.Text + "','" + this.address4txt.Text + "','" + this.contactnotxt.Text + "');";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand(Query, conDatabase);
            MySqlDataReader myReader;

            try{
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("RECORD ADDED");

                while (myReader.Read());
                {

                }
            }
           
            catch (Exception ex){
                MessageBox.Show(ex.Message);
            }

        }
    }
}
