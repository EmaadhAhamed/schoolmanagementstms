﻿namespace SchoolTimeTable
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbluserName = new System.Windows.Forms.Label();
            this.lblpassWord = new System.Windows.Forms.Label();
            this.lbluserRole = new System.Windows.Forms.Label();
            this.txtuserName = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtuserRole = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbluserName
            // 
            this.lbluserName.AutoSize = true;
            this.lbluserName.Location = new System.Drawing.Point(71, 62);
            this.lbluserName.Name = "lbluserName";
            this.lbluserName.Size = new System.Drawing.Size(60, 13);
            this.lbluserName.TabIndex = 0;
            this.lbluserName.Text = "User Name";
            this.lbluserName.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblpassWord
            // 
            this.lblpassWord.AutoSize = true;
            this.lblpassWord.Location = new System.Drawing.Point(71, 110);
            this.lblpassWord.Name = "lblpassWord";
            this.lblpassWord.Size = new System.Drawing.Size(53, 13);
            this.lblpassWord.TabIndex = 1;
            this.lblpassWord.Text = "Password";
            // 
            // lbluserRole
            // 
            this.lbluserRole.AutoSize = true;
            this.lbluserRole.Location = new System.Drawing.Point(71, 158);
            this.lbluserRole.Name = "lbluserRole";
            this.lbluserRole.Size = new System.Drawing.Size(54, 13);
            this.lbluserRole.TabIndex = 2;
            this.lbluserRole.Text = "User Role";
            this.lbluserRole.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtuserName
            // 
            this.txtuserName.Location = new System.Drawing.Point(153, 62);
            this.txtuserName.Name = "txtuserName";
            this.txtuserName.Size = new System.Drawing.Size(100, 20);
            this.txtuserName.TabIndex = 1;
            this.txtuserName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(153, 110);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(100, 20);
            this.txtpassword.TabIndex = 4;
            // 
            // txtuserRole
            // 
            this.txtuserRole.Location = new System.Drawing.Point(153, 151);
            this.txtuserRole.Name = "txtuserRole";
            this.txtuserRole.Size = new System.Drawing.Size(100, 20);
            this.txtuserRole.TabIndex = 3;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(49, 211);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(75, 23);
            this.btnadd.TabIndex = 5;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(178, 211);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 23);
            this.btndelete.TabIndex = 6;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.txtuserRole);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtuserName);
            this.Controls.Add(this.lbluserRole);
            this.Controls.Add(this.lblpassWord);
            this.Controls.Add(this.lbluserName);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbluserName;
        private System.Windows.Forms.Label lblpassWord;
        private System.Windows.Forms.Label lbluserRole;
        private System.Windows.Forms.TextBox txtuserName;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtuserRole;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btndelete;
    }
}