﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SchoolTimeTable
{
    public partial class Form2 : Form
    {
        dbDatabaseConnection obdb = new dbDatabaseConnection();
        int totalSubject = 0;
        
        public Form2()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string grade = txtgrade.Text;
            string datestamp = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
            int res = 0;
            int recCount = 0;
                       
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                try
                {
                    string Query = "INSERT INTO gradesibjects (grade, subject, noofperiods, basketsubject, combineperiod )" +
                               "VALUES('" + txtgrade.Text + "','" + row.Cells[0].Value.ToString() + "','" + row.Cells[1].Value.ToString() + "','" + row.Cells[2].Value.ToString() + "','" + row.Cells[3].Value.ToString() + "');";
                    res = obdb.setData(Query);
                    recCount++;
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            
            }

            if (res > 0)
            {
                try
                {
                    string reference = recCount + " Records";

                    string Query1 = "INSERT INTO audit (operation, tableProcess, userName, dateStamp, reference)" +
                                  "VALUES('" + "INSERT" + "','" + "gradesibjects" + "','" + userHandler.getUserName() + "','" + datestamp + "','" + reference + "');";
                    res = obdb.setData(Query1);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
                MessageBox.Show(recCount + " Records are Inserted ");

                try
                {
                    res = 0;
                    string gradeType = "";
                    int intgrade = Convert.ToInt32(txtgrade.Text.Trim());
                    
                    if ( intgrade > 5 && intgrade < 10 )
                    {
                        gradeType = "Secondry";
                    }
                    else if ( intgrade > 9 && intgrade < 12 )
                    {
                        gradeType = "O/L";
                    }
                    else if ( intgrade > 11 && intgrade < 14 )
                    {
                        gradeType = "A/L";
                    }
                    else 
                    {
                        gradeType = "";
                    }
                    
                    string Query2 = "INSERT INTO grade (grade, noofclasses, gradeType)" +
                                  "VALUES('" + txtgrade.Text + "','" + txtnoofClasses.Text + "','" + gradeType + "');";
                    res = obdb.setData(Query2);
                }
                
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                if (res > 0)
                {
                    string Query3 = "INSERT INTO audit (operation, tableProcess, userName, dateStamp, reference)" +
                                  "VALUES('" + "INSERT" + "','" + "grade" + "','" + userHandler.getUserName() + "','" + datestamp + "','" + " " + "');";
                    res = obdb.setData(Query3);
                    MessageBox.Show("GRADE Record Inserted ");
                }
            }

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                try
                {
                    row.Cells[0].Value = "";
                    row.Cells[1].Value = "";
                    row.Cells[2].Value = "";
                    row.Cells[3].Value = "";
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            
            totalSubject = 0;
            label3.Text = "";

            txtgrade.Text = "";
            txtnoofClasses.Text = "";
            clearFields();

            txtgrade.Focus();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int noOFPeriod = 0;
            dataGridView1.Rows.Add(txtSubject.Text,txtNOP.Text,cmbbasket.Text,cmbcombined.Text);
            int.TryParse(txtNOP.Text, out noOFPeriod);
            totalSubject = totalSubject + noOFPeriod;
            label3.Text = "Total Number of periods are " + totalSubject;

            clearFields();
            txtSubject.Focus();
         
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int val;
            if (!int.TryParse(txtgrade.Text, out val))
            {
                MessageBox.Show("Only integers l to 13 are accepted");
                txtgrade.Clear();
            }

            if (val < 1 ||  val > 14)
            {
                MessageBox.Show("Only integers l to 13 are accepted");
                txtgrade.Clear();
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void clearFields()
        {
 
            txtSubject.Text = "";
            txtNOP.Text = "";
            cmbbasket.SelectedIndex = 0;
            cmbcombined.SelectedIndex = 0;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            frmdM frm = new frmdM();
            frm.Show();
        }

    }
}
