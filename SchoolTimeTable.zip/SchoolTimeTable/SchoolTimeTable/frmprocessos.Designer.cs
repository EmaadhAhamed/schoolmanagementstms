﻿namespace SchoolTimeTable
{
    partial class frmprocessos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnpr4 = new System.Windows.Forms.Button();
            this.btnpr3 = new System.Windows.Forms.Button();
            this.btnpr2 = new System.Windows.Forms.Button();
            this.btnpr1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(188, 214);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 37;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(132, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 13);
            this.label4.TabIndex = 44;
            this.label4.Text = "System User Management";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(132, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 43;
            this.label3.Text = "Displays / Views";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(132, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "Processes";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(132, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 13);
            this.label1.TabIndex = 41;
            this.label1.Text = "Data Management";
            // 
            // btnpr4
            // 
            this.btnpr4.Location = new System.Drawing.Point(22, 162);
            this.btnpr4.Name = "btnpr4";
            this.btnpr4.Size = new System.Drawing.Size(75, 23);
            this.btnpr4.TabIndex = 40;
            this.btnpr4.Text = "4";
            this.btnpr4.UseVisualStyleBackColor = true;
            // 
            // btnpr3
            // 
            this.btnpr3.Location = new System.Drawing.Point(22, 116);
            this.btnpr3.Name = "btnpr3";
            this.btnpr3.Size = new System.Drawing.Size(75, 23);
            this.btnpr3.TabIndex = 39;
            this.btnpr3.Text = "3";
            this.btnpr3.UseVisualStyleBackColor = true;
            // 
            // btnpr2
            // 
            this.btnpr2.Location = new System.Drawing.Point(22, 70);
            this.btnpr2.Name = "btnpr2";
            this.btnpr2.Size = new System.Drawing.Size(75, 23);
            this.btnpr2.TabIndex = 38;
            this.btnpr2.Text = "2";
            this.btnpr2.UseVisualStyleBackColor = true;
            this.btnpr2.Click += new System.EventHandler(this.btnpr2_Click);
            // 
            // btnpr1
            // 
            this.btnpr1.Location = new System.Drawing.Point(22, 24);
            this.btnpr1.Name = "btnpr1";
            this.btnpr1.Size = new System.Drawing.Size(75, 23);
            this.btnpr1.TabIndex = 45;
            this.btnpr1.Text = "1";
            this.btnpr1.UseVisualStyleBackColor = true;
            this.btnpr1.Click += new System.EventHandler(this.btnaDM_Click);
            // 
            // frmprocessos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnpr4);
            this.Controls.Add(this.btnpr3);
            this.Controls.Add(this.btnpr2);
            this.Controls.Add(this.btnpr1);
            this.Name = "frmprocessos";
            this.Text = "Processos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnpr4;
        private System.Windows.Forms.Button btnpr3;
        private System.Windows.Forms.Button btnpr2;
        private System.Windows.Forms.Button btnpr1;
    }
}