﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolTimeTable
{
    public partial class frmlogin : Form
    {
        public static string username;
        dbDatabaseConnection obdb = new dbDatabaseConnection();
        public frmlogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            username = txtUserName.Text;
            string password = txtPassword.Text;
            dt = obdb.getData("SELECT * FROM usertbl WHERE userName='" + username + "' AND password='" + password + "'");
            //dt = obdb.getUser(username, password);

            if (dt.Rows.Count > 0)
            {
                userHandler.setUserName(username);

                if (dt.Rows[0][3].ToString() == "Admin")
                {
                    loginAudit("Admin");
                    this.Hide();
                    frmadmin frm = new frmadmin();
                    frm.Show();
                }

                else if (dt.Rows[0][3].ToString() == "Normal")
                {
                    loginAudit("Normal");            
                    this.Hide();
                    frmusedDB frm = new frmusedDB();
                    frm.Show();
                }

                else
                {
                    MessageBox.Show("You don't have a USER ROLE in this system");
                }
            }

            else
            {
                MessageBox.Show("Username or Password Incorrect");
                txtUserName.Text = "";
                txtPassword.Text = "";
            }

        }


        public string unme()
        {

            string username = txtUserName.Text;
            return username;
        }
       
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void loginAudit(string reference )
        {
            string datestamp = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
            int res = 0;

            try
            {
                string Query1 = "INSERT INTO audit (operation, tableProcess, userName, dateStamp, reference)" +
                              "VALUES('" + "Login" + "','" + "Login" + "','" + userHandler.getUserName() + "','" + datestamp + "','" + reference + "');";
                res = obdb.setData(Query1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        
        }
}