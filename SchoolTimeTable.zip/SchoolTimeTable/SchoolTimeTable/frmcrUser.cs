﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolTimeTable
{
    public partial class frmcrUser : Form
    {
        dbDatabaseConnection obdb = new dbDatabaseConnection();
        //int totalSubject = 0;
        
        public frmcrUser()
        {
            InitializeComponent();
        }

        private void bthchange_Click(object sender, EventArgs e)
        {
            int res = 0;
            string datestamp = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

            if (!string.IsNullOrEmpty(txtuserName.Text) && !string.IsNullOrEmpty(txtpassword.Text) && !string.IsNullOrEmpty(cmbuserRoal.Text)) 
            {
                try
                {
                    string Query = "INSERT INTO usertbl (userName, password, userRole )" +
                               "VALUES('" + txtuserName.Text + "','" + txtpassword.Text + "','" + cmbuserRoal.Text + "');";
                    res = obdb.setData(Query);

//                    string  SELECT MAX(column_name) FROM table_name WHERE condition;
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            else
            {
                MessageBox.Show("User NOT CREATED - Please fill all fields and try again");
            } 
            
            if (res > 0)
            {
                try
                {
                    string Query1 = "INSERT INTO audit (operation, tableProcess, userName, dateStamp, reference)" +
                                  "VALUES('" + "INSERT" + "','" + "usertbl" + "','" + userHandler.getUserName() + "','" + datestamp + "','" + "" + "');";
                    res = obdb.setData(Query1);
                    MessageBox.Show(" USER Created Successfully ");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void btnext_Click(object sender, EventArgs e)
        {
            this.Close();
            frmadmin frm = new frmadmin();
            frm.Show();
        }
    }
}
