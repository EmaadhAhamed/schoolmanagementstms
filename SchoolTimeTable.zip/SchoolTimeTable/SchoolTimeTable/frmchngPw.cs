﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SchoolTimeTable
{
    public partial class frmchngPw : Form
    {
        dbDatabaseConnection obdb = new dbDatabaseConnection();


        public frmchngPw()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
                //check if re entered is correct 
            if (txtpass1.Text != txtpass2.Text)
            {
                MessageBox.Show("Passwords not matching");
            }
            else if (txtuserName.Text == "")
            {

            }
            else
            {
                DataTable dt = new DataTable();
                int res = 0;
                string sql = "SELECT * FROM usertbl WHERE userName='" + txtuserName.Text + "' and password='"+txtOldPassword.Text+"'";
                dt = obdb.getData(sql);

                if (dt.Rows.Count > 0)
                {
                    string sql2 = "UPDATE usertbl SET  password ='"+txtpass1.Text+"' WHERE userName='" + txtuserName.Text + "'";
                    res = obdb.setData(sql);

                    if (res > 0)
                    {
                        string datestamp = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

                        try
                        {
                            string Query1 = "INSERT INTO audit (operation, tableProcess, userName, dateStamp, reference)" +
                                          "VALUES('" + "Password Change" + "','" + "usertbl" + "','" + userHandler.getUserName() + "','" + datestamp + "','" + "" + "');";
                            res = obdb.setData(Query1);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }                        
                        
                        MessageBox.Show("Password CHANGED successfully");
                    }
                
                }

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnext_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            this.Close();
            frmusedDB frm = new frmusedDB();
            frm.Show();
        }
    }
}
