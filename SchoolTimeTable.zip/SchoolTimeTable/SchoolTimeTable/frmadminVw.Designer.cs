﻿namespace SchoolTimeTable
{
    partial class frmadminVw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnpwChange = new System.Windows.Forms.Button();
            this.btndTTT = new System.Windows.Forms.Button();
            this.btndCTT = new System.Windows.Forms.Button();
            this.btnstaffDE = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(183, 219);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(126, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "User Details";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(126, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Teacher Employment Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(126, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Class / Grade Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "Teacher Details";
            // 
            // btnpwChange
            // 
            this.btnpwChange.Location = new System.Drawing.Point(16, 156);
            this.btnpwChange.Name = "btnpwChange";
            this.btnpwChange.Size = new System.Drawing.Size(75, 23);
            this.btnpwChange.TabIndex = 22;
            this.btnpwChange.Text = "4";
            this.btnpwChange.UseVisualStyleBackColor = true;
            // 
            // btndTTT
            // 
            this.btndTTT.Location = new System.Drawing.Point(16, 110);
            this.btndTTT.Name = "btndTTT";
            this.btndTTT.Size = new System.Drawing.Size(75, 23);
            this.btndTTT.TabIndex = 21;
            this.btndTTT.Text = "3";
            this.btndTTT.UseVisualStyleBackColor = true;
            // 
            // btndCTT
            // 
            this.btndCTT.Location = new System.Drawing.Point(16, 64);
            this.btndCTT.Name = "btndCTT";
            this.btndCTT.Size = new System.Drawing.Size(75, 23);
            this.btndCTT.TabIndex = 20;
            this.btndCTT.Text = "2";
            this.btndCTT.UseVisualStyleBackColor = true;
            this.btndCTT.Click += new System.EventHandler(this.btndCTT_Click);
            // 
            // btnstaffDE
            // 
            this.btnstaffDE.Location = new System.Drawing.Point(16, 18);
            this.btnstaffDE.Name = "btnstaffDE";
            this.btnstaffDE.Size = new System.Drawing.Size(75, 23);
            this.btnstaffDE.TabIndex = 27;
            this.btnstaffDE.Text = "1";
            this.btnstaffDE.UseVisualStyleBackColor = true;
            // 
            // frmadminVw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnpwChange);
            this.Controls.Add(this.btndTTT);
            this.Controls.Add(this.btndCTT);
            this.Controls.Add(this.btnstaffDE);
            this.Name = "frmadminVw";
            this.Text = "Admin Views";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnpwChange;
        private System.Windows.Forms.Button btndTTT;
        private System.Windows.Forms.Button btndCTT;
        private System.Windows.Forms.Button btnstaffDE;
    }
}