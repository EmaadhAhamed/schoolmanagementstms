﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SchoolTimeTable
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //This is my connection string i have assigned the database file address path  
            string constring = "datasource=localhost;Initial Catalog=schooltimetable;User ID=root;Password=123";
            //This is my update query in which i am taking input from the user through windows forms and update the record.  
            string Query = "update usertbl set deleted = 'Y'";
            //This is  MySqlConnection here i have created the object and pass my connection string.  
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand(Query, conDatabase);
            MySqlDataReader myReader;
            
            try
            {

                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("Data Updated");
                while (myReader.Read())
                {
                }
                conDatabase.Close();//Connection closed here  
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }  
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;Initial Catalog=schooltimetable;User ID=root;Password=123";
            string Query = "INSERT INTO usertbl (userName, password, userRole)" +
                                 "VALUES('" + this.txtuserName.Text + "','" + this.txtpassword.Text + "','" + this.txtuserRole.Text + "');";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand(Query, conDatabase);
            MySqlDataReader myReader;

            try{
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("USER CREATED SUCCESSFULLY");

                while (myReader.Read());
                {

                }
            }
           
            catch (Exception ex){
                MessageBox.Show(ex.Message);
            }
        }
    }
}
