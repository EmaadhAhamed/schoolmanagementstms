﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolTimeTable
{
    public partial class frmadmin : Form
    {
        public frmadmin()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnaDM_Click(object sender, EventArgs e)
        {
            this.Close();
            frmdM frm = new frmdM();
            frm.Show();
        }

        private void btnviews_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmadminVw frm = new frmadminVw();
            frm.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            frmlogin frm = new frmlogin();
            frm.Show();
        }

        private void btnpro_Click(object sender, EventArgs e)
        {
            this.Close();
            frmprocessos frm = new frmprocessos();
            frm.Show();
        }

        private void btnsysUserCr_Click(object sender, EventArgs e)
        {
            this.Close();
            frmcrUser frm = new frmcrUser();
            frm.Show();
        }
    }
}
