﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SchoolTimeTable
{
    public class userHandler
    {
        private static string username = "";



        public static string getUserName()
        {
            return username;
        }
        public static void setUserName(string userName)
        {
            username = userName;
        }
    }
}
