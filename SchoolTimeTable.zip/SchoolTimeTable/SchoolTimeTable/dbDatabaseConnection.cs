﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace SchoolTimeTable
{
    public class dbDatabaseConnection
    {

        MySqlConnection connection = new MySqlConnection();
        MySqlCommand command = new MySqlCommand();
        MySqlDataAdapter da = new MySqlDataAdapter();
        string constring = "datasource=localhost;Initial Catalog=schooltimetable;User ID=root;Password=123";

        private void setConnection()
        {
            if (connection.ConnectionString == "")
            {
                connection.ConnectionString = constring;
            }

            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                }
            }
            catch (Exception ex)
            {
                
               // throw;
            }
           
        
        }

        //to get data from database
        public DataTable getData(string sqlQuery)
        {
            DataTable dt = new DataTable();

            try
            {
                //Set connection to database
                setConnection();
                //Set connection to command
                command.Connection = connection;
                //Set sql query to command
                command.CommandText = sqlQuery;
                //set command to dataadapter
                da.SelectCommand = command;
                //fill datatable with database data
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                
                throw;
            }
           
            return dt;
        
        }

        // insert / update/delete
        public int setData(string sqlQuery)
        {
            int res = 0;
            try
            {
                setConnection();
                //Set connection to command
                command.Connection = connection;
                //Set sql query to command
                command.CommandText = sqlQuery;
                res = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                
              //  throw;
            }
           
            return res;
        }

    }
}
